# LinuxCTF

## Assumed User
This CTF Questions are easy.
You can solve these Questions used by Linux Commands.
If you can't use "cd" and "ls" command, please learn these commands.


## Question List
- 000 Test Problem(cd,ls)
- 001 READ!(cat)
- 002 Execute this file(chmod)
- 003 gnirtS esreveR(rev)
- 004 copy the file(cp)
- 005 Search String(strings)
- 006 Base Strings(base64)
- 007 Compress(unzip)
- 008 Where is Flag(find)
- 009 Determine!(file)
- 010 Change Name(mv)
- 011 Create Directory(mkdir)
- 012 Delete Directory(rmdir)
- 013 Delete File(rm)
- 014 Tarball(tar)
- 015 Is this zip?(gunzip)
- 016 Is this zip??(bunzip2)
- 017 Line Match(grep)
- 018 Difference(diff)
- 019 Duplicate(uniq)

Copy the "test.txt".
File name is "test2.txt".

After copy, execute "flag".

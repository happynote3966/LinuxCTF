Create directory named "directory"

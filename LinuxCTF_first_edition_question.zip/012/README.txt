Please delete directory named "directory"!

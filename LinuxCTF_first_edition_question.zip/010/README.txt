Please rename.

RENAMEME.txt -> KohinataMiho.txt
